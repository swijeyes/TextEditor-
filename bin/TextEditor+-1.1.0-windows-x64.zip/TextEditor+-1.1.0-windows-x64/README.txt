TextEditor+ 1.1.0 for Windows (portable)
========================================

A lightweight code and text editor. This is the portable version: it needs
no installation and leaves nothing behind on the computer it runs on.

Requirements: Windows 10 or 11, 64-bit (x64).


Running it
----------
1. Extract the whole folder from the zip file, to anywhere you like: your
   Documents folder, the desktop, or a USB stick. Don't run it from inside
   the zip file.
2. Double-click TextEditor+.exe.

The first time, Windows SmartScreen may say "Windows protected your PC",
because the program isn't signed. Click "More info", then "Run anyway".

To open a file, use File > Open, drag the file onto the window, or drag it
onto TextEditor+.exe in File Explorer.


Your settings
-------------
Window size, font, theme and word wrap are saved in the "settings" folder
next to TextEditor+.exe, not in the Windows registry. They travel with the
folder when you copy it.

- To reset everything, delete the contents of the "settings" folder.
- If you'd rather keep settings in the registry like an installed program,
  delete the "settings" folder itself.

The folder you run it from must be writable for settings to be saved.


Removing it
-----------
Delete the folder. Nothing else was installed.


More help
---------
"TextEditor+ User Manual.pdf" in this folder describes every feature and
keyboard shortcut.


Licenses
--------
TextEditor+ is free software, copyright (C) 2026 Sanjeeva Wijeyesakere,
released under the GNU Affero General Public License v3.0 or later
(licenses\agpl-3.0.txt). Source code: https://github.com/swijeyes

It includes these third-party components:

- Qt 6.12.0 (Qt6Core.dll, Qt6Gui.dll, Qt6Widgets.dll, Qt6PrintSupport.dll
  and the files in the "platforms" and "styles" folders), used under the
  GNU Lesser General Public License v3 (licenses\lgpl-3.0.txt, which adds
  to licenses\gpl-3.0.txt). Qt's source code is available from
  https://download.qt.io/official_releases/qt/6.12/6.12.0/ . You may
  replace these DLLs with your own builds of Qt 6.12.

- The LLVM libc++ and libunwind runtime libraries (libc++.dll and
  libunwind.dll) from llvm-mingw, under the Apache License v2.0 with LLVM
  Exceptions (licenses\llvm-mingw-LICENSE.txt).
